import java.util.Scanner;

public class FantasyHockeyLeague {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    Team[] teams = new Team[3];
    Player[] players = new Player[9];

    //Prints the title of the application

    System.out.println("FANTASY HOCKEY APPLICATION");
    System.out.println("TEAM ENTRY");
    System.out.println("================================");
    for (int i = 0; i < 3; i++) {
      //Asks for team name
      System.out.print("Enter team name for team #" + (i + 1) + ": ");
      String teamName = scanner.nextLine();
      teams[i] = new Team(teamName);
      System.out.println("Enter players for " + teamName + ":");
      for (int j = 0; j < 3; j++) {
        //Asks for player name and validates the input
        System.out.print("Enter name for player #" + (j + 1) + ": ");
        String playerName = scanner.nextLine();
        while (playerName.length() < 3) {
          System.out.println("Name must be at least 3 characters long. Please enter a valid name.");
          playerName = scanner.nextLine();
        }
        players[i * 3 + j] = new Player(playerName, teamName);
        //Asks for number of goals and validates the input
        System.out.print("Enter number of goals for " + playerName + ": ");
        int goals = scanner.nextInt();
        while (goals < 0) {
          System.out.println("Goals must be zero or greater. Please enter a valid number.");
          goals = scanner.nextInt();
        }
        players[i * 3 + j].setGoals(goals);
        teams[i].setTotalGoals(teams[i].getTotalGoals() + goals);
        //Asks for number of assists and validates the input
        System.out.print("Enter number of assists for " + playerName + ": ");
        int assists = scanner.nextInt();
        while (assists < 0) {
          System.out.println("Assists must be zero or greater. Please enter a valid number.");
          assists = scanner.nextInt();
        }
        players[i * 3 + j].setAssists(assists);
        teams[i].setTotalAssists(teams[i].getTotalAssists() + assists);
        scanner.nextLine();
      }
      teams[i].setRating();
    }

    // Prints team statistics
    System.out.println("\nREPORT: Stats per Team");
    System.out.println("================================");
    for (int i = 0; i < 3; i++) {
      System.out.println(teams[i].getTeamName() + ": G - " + teams[i].getTotalGoals() + " A - " + teams[i].getTotalAssists() + " Total - " + (teams[i].getTotalGoals() + teams[i].getTotalAssists()) + " Budget - $" + String.format("%.2f", teams[i].getBudget()));
      System.out.println("Rating: " + teams[i].getRating() + " stars");
    }

    System.out.println("\nREPORT: Stats per Player");
    System.out.println("================================");
    for (int i = 0; i < 9; i++) {
      System.out.println(players[i].getTeamName());
      System.out.println(players[i].getPlayerName() + ": G - " + players[i].getGoals() + " A - " + players[i].getAssists() + " Total - " + players[i].getTotal());
    }
  }
}
