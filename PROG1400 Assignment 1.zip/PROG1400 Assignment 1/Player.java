class Player {
  private String playerName;
  private int goals;
  private int assists;
  private String teamName;

  public Player(String playerName, String teamName) {
    this.playerName = playerName;
    this.teamName = teamName;
  }
//setter method for the number of goals the player has scored
  public void setGoals(int goals) {
    this.goals = goals;
  }

  // setter method for the number of assists the player has made
  public void setAssists(int assists) {
    this.assists = assists;
  }

  //getter method for the player's name
  public String getPlayerName() {
    return this.playerName;
  }

  // getter method for the number of goals the player has scored
  public int getGoals() {
    return this.goals;
  }

  //getter method for the number of assists the play has made
  public int getAssists() {
    return this.assists;
  }

  // getter method for the number of assists the player has made 
  public String getTeamName() {
    return this.teamName;
  }

  public int getTotal() {
    return this.goals + this.assists;
  }
}
