class Player {
  private String playerName;
  private int goals;
  private int assists;
  private String teamName;

  public Player(String playerName, String teamName) {
    this.playerName = playerName;
    this.teamName = teamName;
  }

  public void setGoals(int goals) {
    this.goals = goals;
  }

  public void setAssists(int assists) {
    this.assists = assists;
  }

  public String getPlayerName() {
    return this.playerName;
  }

  public int getGoals() {
    return this.goals;
  }

  public int getAssists() {
    return this.assists;
  }

  public String getTeamName() {
    return this.teamName;
  }

  public int getTotal() {
    return this.goals + this.assists;
  }
}
