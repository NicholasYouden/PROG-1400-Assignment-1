import java.util.Scanner;
import java.util.Random;

class Team {
  private String teamName;
  private int totalGoals;
  private int totalAssists;
  private double budget;
  private String rating;

  public Team(String teamName) {
    this.teamName = teamName;
    Random rand = new Random();
    this.budget = (rand.nextDouble() * 100000);
  }

  public void setTotalGoals(int goals) {
    this.totalGoals = goals;
  }

  public void setTotalAssists(int assists) {
    this.totalAssists = assists;
  }

  public void setBudget(double budget) {
    this.budget = budget;
  }

  public void setRating() {
    int total = this.totalGoals + this.totalAssists;
    if (total > 20) {
      this.rating = "***";
    } else if (total >= 10) {
      this.rating = "**";
    } else if (total > 0) {
      this.rating = "*";
    } else {
      this.rating = "0";
    }
  }

  public String getTeamName() {
    return this.teamName;
  }

  public int getTotalGoals() {
    return this.totalGoals;
  }

  public int getTotalAssists() {
    return this.totalAssists;
  }

  public double getBudget() {
    return this.budget;
  }

  public String getRating() {
    return this.rating;
  }
}
